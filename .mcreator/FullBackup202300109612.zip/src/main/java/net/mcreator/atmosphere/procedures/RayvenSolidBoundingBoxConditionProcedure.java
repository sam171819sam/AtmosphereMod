package net.mcreator.atmosphere.procedures;

public class RayvenSolidBoundingBoxConditionProcedure {
	public static boolean execute() {
		return true;
	}
}
